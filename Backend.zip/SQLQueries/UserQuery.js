export const userRegDtlsQuery = `
          INSERT INTO [dbo].[users_reg_dtls] (
            [user_reg_email],
            [user_firstname],
            [user_lastname],
            [user_phone_number],
            [user_status],
            [user_modified_by],
            [user_type],
            [user_is_superadmin],
            [user_logindate],
            [user_logintime],
            [user_token]
        ) OUTPUT INSERTED.user_dtls_id VALUES (
            @user_email,
            @user_pwd,
            @user_firstname,
            @user_lastname,
            @user_phone_number,
            @user_status,
            @user_modified_by,
            @user_type,
            @user_is_superadmin,
            @user_logindate,
            @user_logintime,
            @user_token
        );
`;
